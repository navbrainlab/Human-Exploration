# 跨 trial action space 方法验证报告

## 验证范围

本验证包只处理3D P1数据，检验固定语义标签下的三种pair锚点表示。
不检验Group或score效应；S2和S9坐标不参与正式距离计算。

## 输入与环境

- 输入文件：`E:\桌面\CIBR实习\Human exploration & function learning in high dimensions\Experiment 2 代码复用整理\动作空间分析\全体被试_聚类相对访问顺序\source_data\task1_behavior_raw.csv`
- SHA-256: `ecf1fbafa763bb19369fa941b2838cb69c7bd440dba332b316eb6300e30dd9cf`
- Python: `3.12.7`
- 平台：`Windows-11-10.0.22631-SP0`
- NumPy: `2.4.4`
- pandas: `3.0.3`
- SciPy: `1.17.1`

## 主要结果

- 抽象模板：1680个action，1680个唯一键。
- 全部成对等距验证：1,410,360对；最大绝对误差为7.105e-15。
- pool目录：12个pool × 1680个action = 20,160行。
- 成功投射的真实P1 trial：1,368。
- 被试内相邻转移：1,317。
- 相邻pool共同combo数分布：{0: 453, 3: 864}。
- 三种pair锚点有335/1317次给出相同的行Hamming距离。
- 三种锚点Hamming极差分布：{0: 335, 1: 116, 2: 158, 3: 280, 4: 184, 5: 106, 6: 102, 7: 19, 9: 17}。
- 三种pair锚点全部达到最小刺激语义成本：True。
- 每次转移的最小刺激成本匹配数为20–42。
- 全部最小刺激成本匹配中，仅89/1317次转移具有唯一的行Hamming值。

## 验证断言

```json
{
  "all_pair_anchors_context_optimal": true,
  "all_pair_count": 1410360,
  "all_pair_isometry_max_abs_error": 7.105427357601002e-15,
  "assignment_unique": 1680,
  "contrast_unique": 1680,
  "energy_conservation_max_abs_error": 0.0,
  "fds_each_dimension_all_6": true,
  "observed_mapping_all_unique_exact": true,
  "observed_rows": 1368,
  "observed_unique_keys": 1368,
  "pool_count": 12,
  "pool_fds_all_18": true,
  "pool_keys_all_unique": true,
  "pool_rows_all_1680": true,
  "pool_z2_all_18": true,
  "template_rows": 1680,
  "template_unique_keys": 1680,
  "transition_rows": 1317,
  "within_pool_anchor_bijections_valid": true,
  "within_pool_hamming_preserved_by_all_anchors": true,
  "z2_equals_fds_all_rows": true
}
```

## 解释边界

`hamming_D1xD2`、`hamming_D1xD3`和`hamming_D2xD3`是在两个固定语义feature相同的前提下匹配combo，
再比较其行分配。三者是主要的跨trial对齐视图，不能在结果出现后选择其中“最好看”的一个。

`semantic_transport_sensitivity`汇总所有最小feature成本的一一匹配，只是敏感性分析，
不能称为原始trial内Hamming距离。正式策略轨迹变量是完整计数矩阵以及
`E1`、`E2`、`E3`、`E_int`、`Pur`和`Z`；score与Group只作为来源字段保留。

当前结果支持“真实行为可以稳定投射，且单pool的原始几何被严格保留”。但跨pool不存在唯一自然步长：
982/1317次转移的三种pair锚点并不完全一致，1228/1317次转移在全部最优刺激匹配下也存在多个行Hamming值。
