"""Build all Stage-1 cross-trial action-space validation artifacts."""

from __future__ import annotations

import csv
import hashlib
import json
import platform
import sys
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import yaml
from matplotlib.ticker import MaxNLocator

from cross_trial_action_space import (
    ACTIONS,
    ACTION_INDEX,
    GLOBAL_COMBOS,
    PAIR_ANCHORS,
    PAIR_KEYS,
    ROW_NAMES,
    actual_action_key,
    anchor_action_ids,
    anchor_mapping,
    assignment_coordinates,
    combo_feature_distance,
    contrast_coordinates,
    mapping_context_cost,
    mapping_row_hamming,
    optimal_semantic_matching_summary,
    parse_blocks,
    pool_key,
    position_action_key,
    rows_from_assignment,
    structural_metrics,
)

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
ARRAY_DIR = ROOT / "arrays"
FIGURE_DIR = ROOT / "figures"
REPORT_PATH = ROOT / "method_validation_report.md"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_table(frame: pd.DataFrame, name: str) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    frame.to_csv(DATA_DIR / f"{name}.csv", index=False, encoding="utf-8-sig")
    frame.to_parquet(DATA_DIR / f"{name}.parquet", index=False)


def build_template() -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    assignment = assignment_coordinates()
    contrast = contrast_coordinates()
    rows = []
    for action_id, action in enumerate(ACTIONS):
        row_positions = [
            ",".join(str(i) for i, value in enumerate(action) if value == row_id)
            for row_id in range(3)
        ]
        rows.append(
            {
                "action_id": action_id,
                "action_id_1based": action_id + 1,
                "top_positions": row_positions[0],
                "middle_positions": row_positions[1],
                "bottom_positions": row_positions[2],
                "action_key": position_action_key(action),
                "assignment_27_index": action_id,
                "contrast_16_index": action_id,
            }
        )
    return pd.DataFrame(rows), assignment, contrast


def read_p1(input_csv: Path) -> list[dict[str, str]]:
    with input_csv.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    output = []
    for source_row, row in enumerate(rows, start=2):
        if row["phase"] != "P1":
            continue
        copy = dict(row)
        copy["_source_row_1based"] = str(source_row)
        output.append(copy)
    return output


def identify_pools(p1_rows: list[dict[str, str]]) -> tuple[dict[str, str], dict[str, tuple[str, ...]]]:
    pools = sorted(
        {
            tuple(sorted(sum(parse_blocks(row), ())))
            for row in p1_rows
        }
    )
    if len(pools) != 12:
        raise AssertionError(f"Expected 12 pools, found {len(pools)}")
    pool_by_key = {pool_key(pool): f"P{index:02d}" for index, pool in enumerate(pools, 1)}
    combos_by_id = {pool_id: tuple(key.split(",")) for key, pool_id in pool_by_key.items()}
    return pool_by_key, combos_by_id


def metric_fields(metrics) -> dict[str, object]:
    fields: dict[str, object] = {
        "E1": metrics.energies[0],
        "E2": metrics.energies[1],
        "E3": metrics.energies[2],
        "E_int": metrics.e_int,
        "Pur": metrics.purity,
        "Z": metrics.z,
        "is_FDS": metrics.is_fds,
        "FDS_dimension": metrics.fds_dimension,
        "tendency_dimension": metrics.tendency_dimension,
    }
    for dimension in range(3):
        for row_id in range(3):
            for feature in range(3):
                fields[f"N_D{dimension+1}_{ROW_NAMES[row_id]}_F{feature+1}"] = int(
                    metrics.tables[dimension, row_id, feature]
                )
    return fields


def build_pool_catalog(
    combos_by_id: dict[str, tuple[str, ...]]
) -> tuple[pd.DataFrame, dict[tuple[str, str], dict[str, object]]]:
    records = []
    lookup: dict[tuple[str, str], dict[str, object]] = {}
    for pool_id, pool in combos_by_id.items():
        for pool_action_id, action in enumerate(ACTIONS):
            rows = rows_from_assignment(pool, action)
            key = actual_action_key(rows)
            anchor_ids = anchor_action_ids(rows)
            metrics = structural_metrics(rows)
            record: dict[str, object] = {
                "pool_id": pool_id,
                "pool_combo_key": pool_key(pool),
                "pool_action_id": pool_action_id,
                "pool_action_id_1based": pool_action_id + 1,
                "action_key": key,
                "Top": ",".join(rows[0]),
                "Middle": ",".join(rows[1]),
                "Bottom": ",".join(rows[2]),
                "action_id_D1xD2": anchor_ids["D1xD2"],
                "action_id_D1xD3": anchor_ids["D1xD3"],
                "action_id_D2xD3": anchor_ids["D2xD3"],
                **metric_fields(metrics),
            }
            records.append(record)
            lookup[(pool_id, key)] = record
    return pd.DataFrame(records), lookup


def build_observed_projection(
    p1_rows: list[dict[str, str]],
    pool_by_key: dict[str, str],
    catalog_lookup: dict[tuple[str, str], dict[str, object]],
) -> tuple[pd.DataFrame, dict[tuple[str, str, int], tuple[tuple[str, ...], ...]]]:
    records = []
    rows_lookup = {}
    for row in p1_rows:
        action_rows = parse_blocks(row)
        flattened = tuple(sorted(sum(action_rows, ())))
        pool_id = pool_by_key[pool_key(flattened)]
        key = actual_action_key(action_rows)
        catalog = catalog_lookup[(pool_id, key)]
        subject = str(row["subject"])
        round_id = int(row["round"])
        record = {
            "source_csv_row_1based": int(row["_source_row_1based"]),
            "subject": subject,
            "phase": row["phase"],
            "round": round_id,
            "Group": row["Group"],
            "score": float(row["score"]),
            "pool_id": pool_id,
            "pool_combo_key": pool_key(flattened),
            "action_key": key,
            "pool_action_id": catalog["pool_action_id"],
            "action_id_D1xD2": catalog["action_id_D1xD2"],
            "action_id_D1xD3": catalog["action_id_D1xD3"],
            "action_id_D2xD3": catalog["action_id_D2xD3"],
            "mapping_status": "unique_exact",
        }
        for key_name in (
            "E1", "E2", "E3", "E_int", "Pur", "Z", "is_FDS",
            "FDS_dimension", "tendency_dimension",
        ):
            record[key_name] = catalog[key_name]
        records.append(record)
        rows_lookup[(subject, row["phase"], round_id)] = action_rows
    frame = pd.DataFrame(records).sort_values(["subject", "round"]).reset_index(drop=True)
    return frame, rows_lookup


def build_transitions(
    observed: pd.DataFrame,
    rows_lookup: dict[tuple[str, str, int], tuple[tuple[str, ...], ...]],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    transitions = []
    sensitivity = []
    for subject, subject_frame in observed.groupby("subject", sort=True):
        ordered = subject_frame.sort_values("round")
        records = ordered.to_dict("records")
        for previous, current in zip(records, records[1:]):
            previous_rows = rows_lookup[(str(subject), "P1", int(previous["round"]))]
            current_rows = rows_lookup[(str(subject), "P1", int(current["round"]))]
            previous_pool = tuple(previous["pool_combo_key"].split(","))
            current_pool = tuple(current["pool_combo_key"].split(","))
            anchor_hamming = {}
            anchor_context = {}
            for name, dimensions in PAIR_ANCHORS.items():
                mapping = anchor_mapping(previous_pool, current_pool, dimensions)
                anchor_context[name] = mapping_context_cost(mapping)
                anchor_hamming[name] = mapping_row_hamming(
                    mapping, previous_rows, current_rows
                )
            optimal = optimal_semantic_matching_summary(
                previous_pool, current_pool, previous_rows, current_rows
            )
            anchor_values = np.asarray(list(anchor_hamming.values()), dtype=float)
            transition = {
                "subject": subject,
                "previous_round": int(previous["round"]),
                "current_round": int(current["round"]),
                "previous_pool_id": previous["pool_id"],
                "current_pool_id": current["pool_id"],
                "previous_action_key": previous["action_key"],
                "current_action_key": current["action_key"],
                "pool_intersection_size": len(set(previous_pool) & set(current_pool)),
                "pool_symmetric_difference_size": len(set(previous_pool) ^ set(current_pool)),
                "minimum_context_cost": optimal.context_cost,
                **{
                    f"hamming_{name}": anchor_hamming[name]
                    for name in PAIR_ANCHORS
                },
                **{
                    f"swap_{name}": anchor_hamming[name] / 2.0
                    for name in PAIR_ANCHORS
                },
                "anchor_hamming_min": float(anchor_values.min()),
                "anchor_hamming_max": float(anchor_values.max()),
                "anchor_hamming_mean": float(anchor_values.mean()),
                "anchor_hamming_sd": float(anchor_values.std(ddof=0)),
                "anchor_hamming_range": float(anchor_values.max() - anchor_values.min()),
                "anchor_all_equal": bool(len(set(anchor_hamming.values())) == 1),
                "delta_E1": current["E1"] - previous["E1"],
                "delta_E2": current["E2"] - previous["E2"],
                "delta_E3": current["E3"] - previous["E3"],
                "delta_E_int": current["E_int"] - previous["E_int"],
                "delta_Pur": current["Pur"] - previous["Pur"],
                "delta_Z": current["Z"] - previous["Z"],
                "fds_status_changed": bool(current["is_FDS"] != previous["is_FDS"]),
                "fds_dimension_changed": bool(
                    current["FDS_dimension"] != previous["FDS_dimension"]
                ),
                "tendency_dimension_changed": bool(
                    current["tendency_dimension"] != previous["tendency_dimension"]
                ),
            }
            transitions.append(transition)
            sensitivity.append(
                {
                    "subject": subject,
                    "previous_round": int(previous["round"]),
                    "current_round": int(current["round"]),
                    "minimum_context_cost": optimal.context_cost,
                    "optimal_matching_count": optimal.matching_count,
                    "optimal_row_hamming_min": optimal.row_hamming_min,
                    "optimal_row_hamming_max": optimal.row_hamming_max,
                    "optimal_row_hamming_mean": optimal.row_hamming_mean,
                    "optimal_row_hamming_sd": optimal.row_hamming_sd,
                    "optimal_row_hamming_distribution": json.dumps(
                        optimal.distribution, ensure_ascii=False, sort_keys=True
                    ),
                    "D1xD2_context_cost": anchor_context["D1xD2"],
                    "D1xD3_context_cost": anchor_context["D1xD3"],
                    "D2xD3_context_cost": anchor_context["D2xD3"],
                    "all_pair_anchors_context_optimal": bool(
                        all(value == optimal.context_cost for value in anchor_context.values())
                    ),
                }
            )
    return pd.DataFrame(transitions), pd.DataFrame(sensitivity)


def validate_all(
    template: pd.DataFrame,
    assignment: np.ndarray,
    contrast: np.ndarray,
    catalog: pd.DataFrame,
    observed: pd.DataFrame,
    transitions: pd.DataFrame,
    sensitivity: pd.DataFrame,
) -> dict[str, object]:
    checks: dict[str, object] = {}
    checks["template_rows"] = len(template)
    checks["template_unique_keys"] = template["action_key"].nunique()
    checks["assignment_unique"] = np.unique(assignment, axis=0).shape[0]
    checks["contrast_unique"] = np.unique(np.round(contrast, 12), axis=0).shape[0]

    max_error = 0.0
    for i in range(len(ACTIONS) - 1):
        hamming = np.sum(np.asarray(ACTIONS[i + 1 :]) != np.asarray(ACTIONS[i]), axis=1)
        squared = np.square(contrast[i + 1 :] - contrast[i]).sum(axis=1)
        max_error = max(max_error, float(np.max(np.abs(squared - 2.0 * hamming))))
    checks["all_pair_isometry_max_abs_error"] = max_error
    checks["all_pair_count"] = len(ACTIONS) * (len(ACTIONS) - 1) // 2

    pool_stats = catalog.groupby("pool_id").agg(
        rows=("action_key", "size"),
        unique_keys=("action_key", "nunique"),
        fds=("is_FDS", "sum"),
        z2=("Z", lambda values: int((values == 2).sum())),
        max_energy_error=("E_int", "size"),
    )
    energy_error = np.abs(
        catalog["E1"] + catalog["E2"] + catalog["E3"] + catalog["E_int"] - 6.0
    )
    checks["pool_count"] = catalog["pool_id"].nunique()
    checks["pool_rows_all_1680"] = bool((pool_stats["rows"] == 1680).all())
    checks["pool_keys_all_unique"] = bool((pool_stats["unique_keys"] == 1680).all())
    checks["pool_fds_all_18"] = bool((pool_stats["fds"] == 18).all())
    checks["pool_z2_all_18"] = bool((pool_stats["z2"] == 18).all())
    checks["z2_equals_fds_all_rows"] = bool(((catalog["Z"] == 2) == catalog["is_FDS"]).all())
    checks["energy_conservation_max_abs_error"] = float(energy_error.max())
    fds_by_dimension = (
        catalog[catalog["is_FDS"]]
        .groupby(["pool_id", "FDS_dimension"])
        .size()
        .unstack(fill_value=0)
    )
    checks["fds_each_dimension_all_6"] = bool((fds_by_dimension == 6).all().all())
    checks["observed_rows"] = len(observed)
    checks["observed_unique_keys"] = int(
        observed[["subject", "phase", "round"]].drop_duplicates().shape[0]
    )
    checks["observed_mapping_all_unique_exact"] = bool(
        (observed["mapping_status"] == "unique_exact").all()
    )
    checks["transition_rows"] = len(transitions)
    checks["all_pair_anchors_context_optimal"] = bool(
        sensitivity["all_pair_anchors_context_optimal"].all()
    )
    # Each anchor is a permutation of the same nine pool positions. This proves
    # exact within-pool Hamming preservation for every action pair, even though
    # the observed sequence contains no adjacent repetitions of the same pool.
    anchor_position_bijections = []
    for pool_combo_key in sorted(catalog["pool_combo_key"].unique()):
        pool = tuple(pool_combo_key.split(","))
        for dimensions in PAIR_ANCHORS.values():
            positions = [
                PAIR_KEYS.index((int(combo[dimensions[0]]), int(combo[dimensions[1]])))
                for combo in pool
            ]
            anchor_position_bijections.append(sorted(positions) == list(range(9)))
    checks["within_pool_anchor_bijections_valid"] = bool(all(anchor_position_bijections))
    checks["within_pool_hamming_preserved_by_all_anchors"] = bool(
        checks["within_pool_anchor_bijections_valid"]
    )
    return checks


def make_figures(transitions: pd.DataFrame) -> None:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.size": 12,
            "axes.labelsize": 13,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "axes.linewidth": 1.2,
        }
    )
    fig, ax = plt.subplots(figsize=(5.4, 4.2))
    counts = transitions["pool_intersection_size"].value_counts().sort_index()
    ax.bar(counts.index.astype(str), counts.values, color="#6E6E6E", width=0.62)
    ax.set_xlabel("Shared combos")
    ax.set_ylabel("Adjacent transitions")
    ax.yaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "adjacent_pool_intersection.png", dpi=220)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    values = transitions["anchor_hamming_range"].value_counts().sort_index()
    x_values = values.index.to_numpy(dtype=float)
    ax.bar(x_values, values.values, color="#4C78A8", width=0.68)
    ax.set_xticks(x_values)
    ax.set_xlim(x_values.min() - 0.7, x_values.max() + 0.7)
    ax.set_xlabel("Pair-anchor Hamming range")
    ax.set_ylabel("Adjacent transitions")
    ax.yaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "pair_anchor_disagreement.png", dpi=220)
    plt.close(fig)


def write_report(
    input_csv: Path,
    checks: dict[str, object],
    catalog: pd.DataFrame,
    observed: pd.DataFrame,
    transitions: pd.DataFrame,
    sensitivity: pd.DataFrame,
) -> None:
    intersection_counts = transitions["pool_intersection_size"].value_counts().sort_index()
    anchor_equal = int(transitions["anchor_all_equal"].sum())
    anchor_range_counts = transitions["anchor_hamming_range"].value_counts().sort_index()
    optimal_range = (
        sensitivity["optimal_row_hamming_max"] - sensitivity["optimal_row_hamming_min"]
    )
    report = f"""# 跨 trial action space 方法验证报告

## 验证范围

本验证包只处理3D P1数据，检验固定语义标签下的三种pair锚点表示。
不检验Group或score效应；S2和S9坐标不参与正式距离计算。

## 输入与环境

- 输入文件：`{input_csv}`
- SHA-256: `{sha256(input_csv)}`
- Python: `{sys.version.split()[0]}`
- 平台：`{platform.platform()}`
- NumPy: `{np.__version__}`
- pandas: `{pd.__version__}`
- SciPy: `{scipy.__version__}`

## 主要结果

- 抽象模板：{checks['template_rows']}个action，{checks['template_unique_keys']}个唯一键。
- 全部成对等距验证：{checks['all_pair_count']:,}对；最大绝对误差为{checks['all_pair_isometry_max_abs_error']:.3e}。
- pool目录：{checks['pool_count']}个pool × 1680个action = {len(catalog):,}行。
- 成功投射的真实P1 trial：{len(observed):,}。
- 被试内相邻转移：{len(transitions):,}。
- 相邻pool共同combo数分布：{dict((int(k), int(v)) for k, v in intersection_counts.items())}。
- 三种pair锚点有{anchor_equal}/{len(transitions)}次给出相同的行Hamming距离。
- 三种锚点Hamming极差分布：{dict((int(k), int(v)) for k, v in anchor_range_counts.items())}。
- 三种pair锚点全部达到最小刺激语义成本：{checks['all_pair_anchors_context_optimal']}。
- 每次转移的最小刺激成本匹配数为{int(sensitivity['optimal_matching_count'].min())}–{int(sensitivity['optimal_matching_count'].max())}。
- 全部最小刺激成本匹配中，仅{int((optimal_range == 0).sum())}/{len(sensitivity)}次转移具有唯一的行Hamming值。

## 验证断言

```json
{json.dumps(checks, ensure_ascii=False, indent=2, sort_keys=True)}
```

## 解释边界

`hamming_D1xD2`、`hamming_D1xD3`和`hamming_D2xD3`是在两个固定语义feature相同的前提下匹配combo，
再比较其行分配。三者是主要的跨trial对齐视图，不能在结果出现后选择其中“最好看”的一个。

`semantic_transport_sensitivity`汇总所有最小feature成本的一一匹配，只是敏感性分析，
不能称为原始trial内Hamming距离。正式策略轨迹变量是完整计数矩阵以及
`E1`、`E2`、`E3`、`E_int`、`Pur`和`Z`；score与Group只作为来源字段保留。

当前结果支持“真实行为可以稳定投射，且单pool的原始几何被严格保留”。但跨pool不存在唯一自然步长：
982/1317次转移的三种pair锚点并不完全一致，1228/1317次转移在全部最优刺激匹配下也存在多个行Hamming值。
"""
    REPORT_PATH.write_text(report, encoding="utf-8")


def main() -> None:
    config = yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
    input_csv = (ROOT / config["input_csv"]).resolve()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ARRAY_DIR.mkdir(parents=True, exist_ok=True)

    template, assignment, contrast = build_template()
    p1_rows = read_p1(input_csv)
    pool_by_key, combos_by_id = identify_pools(p1_rows)
    catalog, catalog_lookup = build_pool_catalog(combos_by_id)
    observed, rows_lookup = build_observed_projection(p1_rows, pool_by_key, catalog_lookup)
    transitions, sensitivity = build_transitions(observed, rows_lookup)

    save_table(template, "action_template")
    save_table(catalog, "pool_action_catalog")
    save_table(observed, "observed_p1_projection")
    save_table(transitions, "adjacent_transition_metrics")
    save_table(sensitivity, "semantic_transport_sensitivity")
    np.save(ARRAY_DIR / "action_assignment_27.npy", assignment)
    np.save(ARRAY_DIR / "action_contrast_16.npy", contrast)

    pool_manifest = pd.DataFrame(
        [
            {"pool_id": pool_id, "pool_combo_key": pool_key(combos)}
            for pool_id, combos in combos_by_id.items()
        ]
    )
    save_table(pool_manifest, "pool_manifest")

    checks = validate_all(
        template, assignment, contrast, catalog, observed, transitions, sensitivity
    )
    (DATA_DIR / "validation_checks.json").write_text(
        json.dumps(checks, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    make_figures(transitions)
    write_report(input_csv, checks, catalog, observed, transitions, sensitivity)
    print(json.dumps(checks, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
