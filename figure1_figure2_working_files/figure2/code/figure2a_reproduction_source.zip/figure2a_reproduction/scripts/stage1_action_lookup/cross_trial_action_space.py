"""Core definitions for the cross-trial action-space feasibility validation."""

from __future__ import annotations

import ast
import itertools
import math
from collections import Counter
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

import numpy as np
from scipy.linalg import helmert

ROW_NAMES = ("Top", "Middle", "Bottom")
PAIR_ANCHORS = {
    "D1xD2": (0, 1),
    "D1xD3": (0, 2),
    "D2xD3": (1, 2),
}
PAIR_KEYS = tuple((a, b) for a in (1, 2, 3) for b in (1, 2, 3))
GLOBAL_COMBOS = tuple(
    "".join(map(str, values)) for values in itertools.product((1, 2, 3), repeat=3)
)


def enumerate_assignment_tuples() -> list[tuple[int, ...]]:
    """Match schemes_core.py exactly: Top combinations, then Middle combinations."""
    actions: list[tuple[int, ...]] = []
    for top in itertools.combinations(range(9), 3):
        rest = [index for index in range(9) if index not in top]
        for middle in itertools.combinations(rest, 3):
            assignment = [0] * 9
            for index in middle:
                assignment[index] = 1
            for index in rest:
                if index not in middle:
                    assignment[index] = 2
            actions.append(tuple(assignment))
    if len(actions) != 1680:
        raise AssertionError(f"Expected 1680 actions, found {len(actions)}")
    return actions


ACTIONS = enumerate_assignment_tuples()
ACTION_INDEX = {action: action_id for action_id, action in enumerate(ACTIONS)}
Q9 = helmert(9, full=False).T
Q3 = helmert(3, full=False).T


def assignment_matrix(action: Sequence[int]) -> np.ndarray:
    matrix = np.zeros((9, 3), dtype=np.int8)
    matrix[np.arange(9), np.asarray(action, dtype=int)] = 1
    return matrix


def assignment_coordinates() -> np.ndarray:
    return np.stack([assignment_matrix(action).reshape(-1) for action in ACTIONS])


def contrast_coordinates() -> np.ndarray:
    return np.stack(
        [(Q9.T @ assignment_matrix(action) @ Q3).reshape(-1) for action in ACTIONS]
    )


def position_action_key(action: Sequence[int]) -> str:
    rows = [
        ",".join(str(index) for index, row in enumerate(action) if row == row_id)
        for row_id in range(3)
    ]
    return ";".join(rows)


def parse_blocks(row: Mapping[str, str]) -> tuple[tuple[str, ...], ...]:
    parsed = []
    for column in ("block1", "block2", "block3"):
        values = tuple(sorted(str(value) for value in ast.literal_eval(row[column])))
        if len(values) != 3:
            raise ValueError(f"{column} does not contain exactly 3 combos")
        parsed.append(values)
    flattened = sum(parsed, ())
    if len(set(flattened)) != 9:
        raise ValueError("Action does not contain 9 distinct combos")
    lengths = {len(combo) for combo in flattened}
    if lengths != {3}:
        raise ValueError(f"Expected 3D combos, got lengths {sorted(lengths)}")
    return tuple(parsed)


def actual_action_key(rows: Sequence[Sequence[str]]) -> str:
    return ";".join(",".join(sorted(row)) for row in rows)


def pool_key(combos: Iterable[str]) -> str:
    return ",".join(sorted(combos))


def rows_from_assignment(
    pool: Sequence[str], action: Sequence[int]
) -> tuple[tuple[str, ...], ...]:
    return tuple(
        tuple(combo for combo, row_id in zip(pool, action) if row_id == target)
        for target in range(3)
    )


def action_from_rows(
    pool: Sequence[str], rows: Sequence[Sequence[str]]
) -> tuple[int, ...]:
    row_by_combo = {
        combo: row_id for row_id, action_row in enumerate(rows) for combo in action_row
    }
    if set(row_by_combo) != set(pool):
        raise ValueError("Rows do not contain exactly the pool combos")
    return tuple(row_by_combo[combo] for combo in pool)


def contingency_tables(
    rows: Sequence[Sequence[str]],
) -> np.ndarray:
    tables = np.zeros((3, 3, 3), dtype=np.int8)  # dimension, row, feature
    for dimension in range(3):
        for row_id, action_row in enumerate(rows):
            for combo in action_row:
                tables[dimension, row_id, int(combo[dimension]) - 1] += 1
    return tables


@dataclass(frozen=True)
class StructuralMetrics:
    energies: tuple[float, float, float]
    e_int: float
    purity: float
    z: int
    is_fds: bool
    fds_dimension: int
    tendency_dimension: int
    tables: np.ndarray


def structural_metrics(rows: Sequence[Sequence[str]], tolerance: float = 1e-9) -> StructuralMetrics:
    tables = contingency_tables(rows)
    energies = tuple(
        float(np.square(tables[dimension]).sum() / 3.0 - 3.0)
        for dimension in range(3)
    )
    e_int = 6.0 - sum(energies)
    energy_sum = sum(energies)
    purity = (
        1.0
        if energy_sum < tolerance
        else float(sum(value * value for value in energies) / (energy_sum * energy_sum))
    )
    z = sum(abs(value) < tolerance for value in energies)
    fds_dimensions = []
    for dimension in range(3):
        if all(
            len({combo[dimension] for combo in action_row}) == 1
            for action_row in rows
        ):
            fds_dimensions.append(dimension + 1)
    is_fds = bool(fds_dimensions)
    fds_dimension = fds_dimensions[0] if len(fds_dimensions) == 1 else -1
    maximum = max(energies)
    maxima = [index + 1 for index, value in enumerate(energies) if abs(value - maximum) < tolerance]
    tendency_dimension = maxima[0] if len(maxima) == 1 else -1
    return StructuralMetrics(
        energies=energies,
        e_int=e_int,
        purity=purity,
        z=z,
        is_fds=is_fds,
        fds_dimension=fds_dimension,
        tendency_dimension=tendency_dimension,
        tables=tables,
    )


def anchor_assignment(
    rows: Sequence[Sequence[str]], dimensions: tuple[int, int]
) -> tuple[int, ...]:
    row_by_combo = {
        combo: row_id for row_id, action_row in enumerate(rows) for combo in action_row
    }
    combo_by_pair: dict[tuple[int, int], str] = {}
    for combo in row_by_combo:
        pair = (int(combo[dimensions[0]]), int(combo[dimensions[1]]))
        if pair in combo_by_pair:
            raise ValueError(f"Pair {pair} is not unique for dimensions {dimensions}")
        combo_by_pair[pair] = combo
    if set(combo_by_pair) != set(PAIR_KEYS):
        raise ValueError(f"Pool is not orthogonal for dimensions {dimensions}")
    return tuple(row_by_combo[combo_by_pair[pair]] for pair in PAIR_KEYS)


def anchor_action_ids(rows: Sequence[Sequence[str]]) -> dict[str, int]:
    return {
        name: ACTION_INDEX[anchor_assignment(rows, dimensions)]
        for name, dimensions in PAIR_ANCHORS.items()
    }


def combo_feature_distance(left: str, right: str) -> int:
    return sum(a != b for a, b in zip(left, right))


def anchor_mapping(
    left_pool: Sequence[str], right_pool: Sequence[str], dimensions: tuple[int, int]
) -> dict[str, str]:
    right_by_pair = {
        (int(combo[dimensions[0]]), int(combo[dimensions[1]])): combo
        for combo in right_pool
    }
    if len(right_by_pair) != 9:
        raise ValueError("Right pool is not orthogonal for the requested anchor")
    mapping = {}
    for combo in left_pool:
        pair = (int(combo[dimensions[0]]), int(combo[dimensions[1]]))
        mapping[combo] = right_by_pair[pair]
    return mapping


def mapping_context_cost(mapping: Mapping[str, str]) -> int:
    return sum(combo_feature_distance(left, right) for left, right in mapping.items())


def mapping_row_hamming(
    mapping: Mapping[str, str],
    left_rows: Sequence[Sequence[str]],
    right_rows: Sequence[Sequence[str]],
) -> int:
    left_row = {
        combo: row_id for row_id, action_row in enumerate(left_rows) for combo in action_row
    }
    right_row = {
        combo: row_id for row_id, action_row in enumerate(right_rows) for combo in action_row
    }
    return sum(left_row[left] != right_row[right] for left, right in mapping.items())


@dataclass(frozen=True)
class OptimalMatchingSummary:
    context_cost: int
    matching_count: int
    row_hamming_min: int
    row_hamming_max: int
    row_hamming_mean: float
    row_hamming_sd: float
    distribution: dict[int, int]


def optimal_semantic_matching_summary(
    left_pool: Sequence[str],
    right_pool: Sequence[str],
    left_rows: Sequence[Sequence[str]],
    right_rows: Sequence[Sequence[str]],
) -> OptimalMatchingSummary:
    """Exact bitmask DP over all minimum-feature-cost bijections."""
    left_pool = tuple(sorted(left_pool))
    right_pool = tuple(sorted(right_pool))
    left_row = {
        combo: row_id for row_id, action_row in enumerate(left_rows) for combo in action_row
    }
    right_row = {
        combo: row_id for row_id, action_row in enumerate(right_rows) for combo in action_row
    }
    states: dict[int, tuple[int, Counter[int]]] = {0: (0, Counter({0: 1}))}
    for left_combo in left_pool:
        next_states: dict[int, tuple[int, Counter[int]]] = {}
        for mask, (cost, distribution) in states.items():
            for index, right_combo in enumerate(right_pool):
                if mask & (1 << index):
                    continue
                new_mask = mask | (1 << index)
                new_cost = cost + combo_feature_distance(left_combo, right_combo)
                row_change = int(left_row[left_combo] != right_row[right_combo])
                shifted = Counter(
                    {value + row_change: count for value, count in distribution.items()}
                )
                if new_mask not in next_states or new_cost < next_states[new_mask][0]:
                    next_states[new_mask] = (new_cost, shifted)
                elif new_cost == next_states[new_mask][0]:
                    next_states[new_mask][1].update(shifted)
        states = next_states
    context_cost, distribution = states[(1 << 9) - 1]
    matching_count = sum(distribution.values())
    mean = sum(value * count for value, count in distribution.items()) / matching_count
    variance = (
        sum((value - mean) ** 2 * count for value, count in distribution.items())
        / matching_count
    )
    return OptimalMatchingSummary(
        context_cost=context_cost,
        matching_count=matching_count,
        row_hamming_min=min(distribution),
        row_hamming_max=max(distribution),
        row_hamming_mean=float(mean),
        row_hamming_sd=float(math.sqrt(variance)),
        distribution=dict(sorted(distribution.items())),
    )

