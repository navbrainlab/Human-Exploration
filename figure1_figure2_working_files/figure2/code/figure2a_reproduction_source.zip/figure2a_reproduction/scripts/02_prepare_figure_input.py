from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OBSERVED = ROOT / "scripts" / "stage1_action_lookup" / "data" / "observed_p1_projection.parquet"
OUT = ROOT / "input_data"
ENERGY = ["E1", "E2", "E3"]

def cell_key(frame):
    return frame[ENERGY].round(9).astype(str).agg("|".join, axis=1)

def main():
    obs = pd.read_parquet(OBSERVED).copy()
    obs = obs.sort_values(["subject", "phase", "round", "source_csv_row_1based"]).reset_index(drop=True)
    obs["trial_index_subject"] = obs.groupby("subject").cumcount() + 1
    obs["subject_trial_count"] = obs.groupby("subject")["trial_index_subject"].transform("max")
    obs["trial_progress"] = np.where(obs.subject_trial_count > 1,
        (obs.trial_index_subject - 1) / (obs.subject_trial_count - 1), 0.5)
    obs["energy_cell_id"] = cell_key(obs)

    within = (obs.groupby(["subject", "energy_cell_id"] + ENERGY, as_index=False)
              .agg(mean_trial_index=("trial_index_subject", "mean"),
                   mean_trial_progress=("trial_progress", "mean"),
                   visit_count=("round", "size")))
    within["visit_rank"] = within.groupby("subject")["mean_trial_index"].rank(method="average")
    within["visited_cluster_count"] = within.groupby("subject")["energy_cell_id"].transform("size")
    within["rank_normalized_order"] = np.where(within.visited_cluster_count > 1,
        (within.visit_rank - 1) / (within.visited_cluster_count - 1), 0.5)

    agg = (within.groupby(["energy_cell_id"] + ENERGY, as_index=False)
           .agg(mean_trial_index=("mean_trial_index", "mean"),
                mean_trial_progress=("mean_trial_progress", "mean"),
                mean_rank_normalized_order=("rank_normalized_order", "mean"),
                participants=("subject", "nunique"),
                total_visits=("visit_count", "sum")))
    agg = agg.sort_values(["mean_rank_normalized_order"] + ENERGY).reset_index(drop=True)
    agg["display_order_rank"] = np.arange(1, len(agg) + 1)
    agg["relative_visit_order"] = (agg.display_order_rank - 1) / (len(agg) - 1)
    agg["is_FDS_vertex"] = agg[ENERGY].apply(lambda r: sorted(r.tolist()) == [0.0, 0.0, 6.0], axis=1)
    OUT.mkdir(parents=True, exist_ok=True)
    obs.to_csv(OUT / "trial_level_energy_visits.csv", index=False, encoding="utf-8-sig")
    within.to_csv(OUT / "subject_cluster_visit_summary.csv", index=False, encoding="utf-8-sig")
    agg.to_csv(OUT / "aggregate_cluster_visit_timing.csv", index=False, encoding="utf-8-sig")
    qc = {"raw_p1_trials": int(len(obs)), "participants": int(obs.subject.nunique()),
          "clusters": int(len(agg)), "aggregated_visit_sum": int(agg.total_visits.sum())}
    (OUT / "preprocessing_qc.json").write_text(json.dumps(qc, indent=2), encoding="utf-8")
    assert qc == {"raw_p1_trials": 1368, "participants": 51, "clusters": 24, "aggregated_visit_sum": 1368}

if __name__ == "__main__": main()
