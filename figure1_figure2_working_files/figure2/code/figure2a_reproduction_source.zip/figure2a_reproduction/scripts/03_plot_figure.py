from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "input_data" / "aggregate_cluster_visit_timing.csv"
FIG = ROOT / "figures"
OUT = ROOT / "outputs"
PALETTE = ["#352A87", "#0866DE", "#08D0D2", "#0FAEB8", "#64BD85", "#BEBB5F", "#FCC237", "#F9FB0E"]

def project(d):
    # Pixel-space orthographic projection measured from the supplied 1920x1280 target.
    origin=np.array([885.,688.]); d1=np.array([526.,990.]); d2=np.array([1540.,723.]); d3=np.array([878.,167.])
    return origin + d.E1.to_numpy()[:,None]/6*(d1-origin) + d.E2.to_numpy()[:,None]/6*(d2-origin) + d.E3.to_numpy()[:,None]/6*(d3-origin)

def arrow(ax, a, b):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=17,lw=3.0,color='#111111',zorder=1))

def main():
    d=pd.read_csv(DATA); xy=project(d)
    cmap=LinearSegmentedColormap.from_list('visit_order', PALETTE, N=256); norm=Normalize(0,1)
    t=(d.total_visits-d.total_visits.min())/(d.total_visits.max()-d.total_visits.min())
    diameter_px=np.sqrt(560 + 1120*t) * 1.5
    diameter_px=np.where(d.is_FDS_vertex.astype(str).str.lower().eq('true'),diameter_px*1.48,diameter_px)
    sizes=(diameter_px*72/200)**2
    fig,ax=plt.subplots(figsize=(9.6,6.4),dpi=200)
    fig.subplots_adjust(0,0,1,1)
    ax.set_xlim(0,1920); ax.set_ylim(1280,0); ax.axis('off')
    origin=(885,688); arrow(ax,origin,(409,1092)); arrow(ax,origin,(1740,746)); arrow(ax,origin,(878,63))
    ax.scatter(xy[:,0],xy[:,1],s=sizes,c=d.relative_visit_order,cmap=cmap,norm=norm,
               edgecolor='#6d6d6d',linewidth=0.75,zorder=3)
    ax.text(620,1090,'Dimension 1',fontsize=13,ha='center'); ax.text(1582,829,'Dimension 2',fontsize=13,ha='center')
    ax.text(878,54,'Dimension 3',fontsize=13,ha='center',va='bottom')
    cax=fig.add_axes([470/1920,(1280-803)/1280,39/1920,(803-241)/1280])
    cb=fig.colorbar(matplotlib.cm.ScalarMappable(norm=norm,cmap=cmap),cax=cax,ticks=[])
    cb.outline.set_linewidth(1.0)
    ax.text(393,225,'Relative visit order',fontsize=10.5,fontweight='bold')
    ax.text(525,263,'Late',fontsize=10,va='center'); ax.text(525,793,'Early',fontsize=10,va='center')
    ax.scatter([1160],[266],s=(31*72/200)**2,c=[cmap(.55)],edgecolor='#6d6d6d',linewidth=.75)
    ax.text(1210,266,'Same-enrichment choice (Size = visits)',fontsize=10.5,va='center')
    FIG.mkdir(parents=True,exist_ok=True); OUT.mkdir(parents=True,exist_ok=True)
    for ext in ('png','pdf','svg'):
        fig.savefig(FIG/f'aggregate_cluster_relative_visit_order.{ext}',dpi=200,facecolor='white',bbox_inches=None)
    plt.close(fig)
    summary={"color_metric":"rank-normalized relative cluster visit order","size_metric":"total trial-level visits",
             "n_participants":int(d.participants.max()),"n_clusters":int(len(d)),"total_visits":int(d.total_visits.sum()),
             "early_cluster":d.loc[d.relative_visit_order.idxmin(),"energy_cell_id"],
             "late_cluster":d.loc[d.relative_visit_order.idxmax(),"energy_cell_id"]}
    (OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    d.to_csv(OUT/'plotted_cluster_statistics.csv',index=False,encoding='utf-8-sig')

if __name__=='__main__': main()
