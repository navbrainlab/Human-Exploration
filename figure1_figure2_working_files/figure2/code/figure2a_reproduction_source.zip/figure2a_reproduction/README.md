# 全体被试聚类相对访问顺序

本文件夹只复现一张图：24 个同富集选择聚类的相对访问顺序。颜色表示从早到晚的相对顺序，气泡面积表示访问次数。

## 一键复现

在 PowerShell 中运行：

```powershell
.\run_reproduction.ps1
```

流程从 `source_data/task1_behavior_raw.csv` 开始，依次重建动作映射、图表输入、分析输出和 PNG/PDF/SVG 图。依赖见 `requirements.txt`。

## 文件职责

- `source_data/`：未经本图流程加工的 Task 1 行为原始 CSV。
- `scripts/stage1_action_lookup/`：原始动作空间映射与能量坐标计算代码。
- `input_data/`：逐试次、被试×聚类及最终聚类级图表输入。
- `outputs/`：图中统计量与机器可读摘要。
- `figures/`：仅包含本图的三种格式。
- `reference/target_figure.png`：用户提供的布局参照，不参与计算。

统计单元和变换细节见 `PREPROCESSING_LOGIC.md`；运行核验见 `QC_VERIFICATION.md`。
