$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = 'python'
Push-Location (Join-Path $root 'scripts\stage1_action_lookup')
try { & $python 'run_validation.py' } finally { Pop-Location }
& $python (Join-Path $root 'scripts\02_prepare_figure_input.py')
& $python (Join-Path $root 'scripts\03_plot_figure.py')
Write-Host "Reproduction complete: $root\figures\aggregate_cluster_relative_visit_order.png"
